"""Cria (ou atualiza) um usuário da equipe com a senha que você digitar.

Use isto em vez de criar usuário à mão no Atlas: o hash da senha sai no formato certo.

    python criar_admin.py seu@email.com "Seu Nome"             # cria admin
    python criar_admin.py outro@email.com "Fulana" corretor    # cria corretor

Se o e-mail já existir, troca a senha (e o papel) desse usuário.
Lê MONGO_URI e MONGO_DB do .env, igual ao site.
"""
import getpass
import re
import sys
from datetime import datetime, timezone

from werkzeug.security import generate_password_hash

from app import create_app
from extensions import ensure_indexes, get_db

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 1
    email, nome = argv[0].strip().lower(), argv[1].strip()
    papel = argv[2] if len(argv) > 2 else "admin"
    if not EMAIL_RE.match(email) or len(nome) < 3 or papel not in ("admin", "corretor"):
        print("Uso inválido: confira o e-mail, o nome (mín. 3 letras) e o papel (admin ou corretor).")
        return 1

    senha = getpass.getpass("Senha (mín. 8 caracteres): ")
    if not 8 <= len(senha) <= 128:
        print("A senha precisa ter entre 8 e 128 caracteres.")
        return 1
    if senha != getpass.getpass("Repita a senha: "):
        print("As senhas não conferem.")
        return 1

    app = create_app()
    with app.app_context():
        db = get_db()
        ensure_indexes()
        existente = db.users.find_one({"email": email})
        if existente:
            db.users.update_one(
                {"_id": existente["_id"]},
                {"$set": {"senha_hash": generate_password_hash(senha), "papel": papel, "ativo": True}, "$inc": {"sessao_versao": 1}},
            )
            print(f"Usuário {email} atualizado ({papel}).")
        else:
            agora = datetime.now(timezone.utc)
            db.users.insert_one({
                "nome": nome, "email": email, "senha_hash": generate_password_hash(senha), "telefone": "", "documento": None,
                "papel": papel, "ativo": True, "favoritos": [], "sessao_versao": 0,
                "lgpd": {"aceite_em": agora, "versao_politica": "equipe"}, "criado_em": agora, "ultimo_login": None,
            })
            print(f"Usuário {email} criado ({papel}).")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
